// import { FFmpeg } from '@ffmpeg/ffmpeg';

// const ffmpeg = new FFmpeg();
// console.log("🚀 ~ ffmpeg:", ffmpeg);
// ffmpeg.load();

// self.onmessage = async (event) => {
//     const { data } = event;
//     console.log("🚀 ~ self.onmessage= ~ data:", data);
//     // Use FFmpeg based on the data received from the main thread
//     // For example, if data is an object with a 'command' property:
//     if (data.command === 'version') {
//         const result = await ffmpeg.run('-version');
//         self.postMessage(result);
//     }
// };
console.log("🚀 ~ self:");
